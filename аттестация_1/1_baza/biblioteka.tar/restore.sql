--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE biblioteka;
--
-- Name: biblioteka; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE biblioteka WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE biblioteka OWNER TO postgres;

\unrestrict (null)
\connect biblioteka
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chitatel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chitatel (
    chitatel_id integer NOT NULL,
    fio character varying(100) NOT NULL,
    vozrast integer,
    lyubimyy_zhanr character varying(40),
    lyubimaya_tema character varying(40),
    CONSTRAINT chitatel_vozrast_check CHECK (((vozrast >= 10) AND (vozrast <= 80)))
);


ALTER TABLE public.chitatel OWNER TO postgres;

--
-- Name: kniga; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kniga (
    kniga_id integer NOT NULL,
    nazvanie character varying(200) NOT NULL,
    avtor character varying(100),
    zhanr character varying(40),
    tema character varying(40),
    god integer
);


ALTER TABLE public.kniga OWNER TO postgres;

--
-- Name: vydacha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vydacha (
    vydacha_id integer NOT NULL,
    chitatel_id integer,
    kniga_id integer,
    data_vydachi date,
    srok_sdachi date,
    data_vozvrata date,
    otsenka integer,
    CONSTRAINT vydacha_check CHECK ((srok_sdachi >= data_vydachi)),
    CONSTRAINT vydacha_check1 CHECK (((data_vozvrata IS NULL) OR (data_vozvrata >= data_vydachi))),
    CONSTRAINT vydacha_otsenka_check CHECK (((otsenka IS NULL) OR ((otsenka >= 1) AND (otsenka <= 5))))
);


ALTER TABLE public.vydacha OWNER TO postgres;

--
-- Name: v_priznaki_prosrochki; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_priznaki_prosrochki AS
 SELECT v.vydacha_id,
    v.chitatel_id,
    c.fio,
    c.vozrast,
    c.lyubimyy_zhanr,
    c.lyubimaya_tema,
    k.kniga_id,
    k.nazvanie,
    k.avtor,
    k.zhanr,
    k.tema,
    v.data_vydachi,
    v.srok_sdachi,
    v.data_vozvrata,
    v.otsenka,
    (v.srok_sdachi - v.data_vydachi) AS srok_dney,
        CASE
            WHEN ((v.data_vozvrata IS NOT NULL) AND (v.data_vozvrata > v.srok_sdachi)) THEN 1
            WHEN ((v.data_vozvrata IS NULL) AND (v.srok_sdachi < CURRENT_DATE)) THEN 1
            ELSE 0
        END AS prosrochka,
        CASE
            WHEN (v.data_vozvrata IS NULL) THEN 1
            ELSE 0
        END AS na_rukah,
        CASE
            WHEN ((k.zhanr)::text = (c.lyubimyy_zhanr)::text) THEN 1
            ELSE 0
        END AS zhanr_sovpal,
        CASE
            WHEN ((k.tema)::text = (c.lyubimaya_tema)::text) THEN 1
            ELSE 0
        END AS tema_sovpala,
    count(v.vydacha_id) OVER (PARTITION BY k.kniga_id) AS skok_brali,
    avg(v.otsenka) OVER (PARTITION BY k.kniga_id) AS sred_ocenka_knigi
   FROM ((public.vydacha v
     JOIN public.chitatel c ON ((c.chitatel_id = v.chitatel_id)))
     JOIN public.kniga k ON ((k.kniga_id = v.kniga_id)));


ALTER VIEW public.v_priznaki_prosrochki OWNER TO postgres;

--
-- Data for Name: chitatel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chitatel (chitatel_id, fio, vozrast, lyubimyy_zhanr, lyubimaya_tema) FROM stdin;
\.
COPY public.chitatel (chitatel_id, fio, vozrast, lyubimyy_zhanr, lyubimaya_tema) FROM '$$PATH$$/4801.dat';

--
-- Data for Name: kniga; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kniga (kniga_id, nazvanie, avtor, zhanr, tema, god) FROM stdin;
\.
COPY public.kniga (kniga_id, nazvanie, avtor, zhanr, tema, god) FROM '$$PATH$$/4802.dat';

--
-- Data for Name: vydacha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vydacha (vydacha_id, chitatel_id, kniga_id, data_vydachi, srok_sdachi, data_vozvrata, otsenka) FROM stdin;
\.
COPY public.vydacha (vydacha_id, chitatel_id, kniga_id, data_vydachi, srok_sdachi, data_vozvrata, otsenka) FROM '$$PATH$$/4803.dat';

--
-- Name: chitatel chitatel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chitatel
    ADD CONSTRAINT chitatel_pkey PRIMARY KEY (chitatel_id);


--
-- Name: kniga kniga_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kniga
    ADD CONSTRAINT kniga_pkey PRIMARY KEY (kniga_id);


--
-- Name: vydacha vydacha_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vydacha
    ADD CONSTRAINT vydacha_pkey PRIMARY KEY (vydacha_id);


--
-- Name: vydacha vydacha_chitatel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vydacha
    ADD CONSTRAINT vydacha_chitatel_id_fkey FOREIGN KEY (chitatel_id) REFERENCES public.chitatel(chitatel_id);


--
-- Name: vydacha vydacha_kniga_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vydacha
    ADD CONSTRAINT vydacha_kniga_id_fkey FOREIGN KEY (kniga_id) REFERENCES public.kniga(kniga_id);


--
-- PostgreSQL database dump complete
--

